# Abel — Aplicativo Escolar PWA

Projeto inicial responsivo com visual de aplicativo, manifest, service worker e botão de instalação compatível com navegadores que oferecem suporte a PWA.

## Personalização
- Desenvolvedora: Maria Elenilda Almeida Mesquita
- Turma: Informática
- Série: 3º ano
- Tema visual: azul-marinho, azul-ciano e amarelo, inspirado na logo oficial do Abel
- Logo oficial incluída em `assets/logo-abel.png` (Escola Estadual Professor Abel Freire Coelho).

## Publicar no GitHub Pages
1. Crie um repositório público chamado `abel-pwa` no GitHub.
2. Envie todos os arquivos desta pasta para a raiz do repositório.
3. No repositório, abra **Settings → Pages**.
4. Em **Build and deployment**, escolha **Deploy from a branch**, branch `main` e pasta `/(root)`, depois salve.
5. Aguarde a publicação. O endereço será `https://SEU-USUARIO.github.io/abel-pwa/` (troque `SEU-USUARIO` pelo seu nome de usuário real do GitHub).

## Instalar no celular
Abra o endereço publicado em um navegador compatível. No Android, use o menu do navegador e escolha **Instalar app** ou **Adicionar à tela inicial**, conforme a opção disponível.

## Observação
Este é um modelo inicial; a logo e as cores definitivas devem ser confirmadas antes da entrega final. A instalação PWA depende de hospedagem HTTPS e suporte do navegador.
